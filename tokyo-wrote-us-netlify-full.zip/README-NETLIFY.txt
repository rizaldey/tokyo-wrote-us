TOKYO WROTE US — Netlify static site

To publish:
1. Extract this ZIP.
2. Open https://app.netlify.com/drop while signed in to Netlify.
3. Drag the extracted folder (the folder containing index.html and assets/) into the drop zone.
4. When deployment completes, open the .netlify.app URL.

Files:
- index.html: homepage
- chapter-one.html: Chapter One reading page
- assets/: original local images and illustrations

Keep the assets folder alongside the HTML files so the images load correctly.
