Tokyo Wrote Us website update

Open index.html to view the homepage. Keep the assets folder alongside index.html and chapter-one.html. Theo’s portrait now uses the supplied blue-ink sketch, cropped to remove the external tape and paper frame while keeping the undercut visible. The Chapters navigation tab has been removed; Chapter One remains available. The Nagoya-Tokyo-Seoul panorama and selected washi-tape accents are preserved.
